# external-fulfillment-sterling-oms
This repo consists of the sterling OMS Extesion files (Java, XML,XSLT,properti files) required for extensions.jar build and deployment into the OMS SaaS environment.

It also consists of CDT xmls imported from the Master config environment for maintaining the latest versoning of Code and configuration.

The junit test classes and jar files are not part of the SaaS build and deployment and only to be used in local dev environment.

# Repo Owner
Feature Team-3

# Repo Type
Sterling OMS Code and Configuration

# IBM Dev environment Set up
Follow the [Confluence Link](https://wawaappdev.atlassian.net/wiki/spaces/OMS/pages/420413904/Sterling+OMS+Local+Environment+Setup+using+docker+based+devtoolkit)
 for the local development environment set up using the IBM docker based devtooklit.


# java Version
Java version 1.8

# OMS Build and Deployment Steps
Follow the [Confluence Link](https://wawaappdev.atlassian.net/wiki/spaces/OMS/pages/335578393/OMS+Build+and+Deployment+-+Plan+B+Without+CI+CD)
 for detailed OMS build and deployment steps for extension.jar .


# Steps to upgrade and validate IBM dev tool kit jar
Follow the below confluence links related to quarterly devtoolkit upgrade and validation:

[Confluence Link](https://wawaappdev.atlassian.net/wiki/spaces/OMS/pages/653198018/Docker+devtoolkit+upgrade+to+20.1+version+in+Local) for Local upgrade.



[Confluence Link](https://wawaappdev.atlassian.net/wiki/spaces/OMS/pages/602047842/DTFI-1262%2BOMS%2BValidation%2Bof%2BSaaS%2Benvironment%2Bpost%2B20.1%2Bupgrade) for SaaS validation steps Post upgrade.



# Steps to run junit tests in local dev laptop
1.Chekout the OMS codebase from the repository along with the junit jars.

2.Import the project to local IDE along with all the sterling and junit specific jars

3.Run the each junit test java classes for executing the junit test cases manually 

Note:For the extensions.jar build process uses the IBM ANT build scripts which doesn't support the execution of junit test cases during the build .



